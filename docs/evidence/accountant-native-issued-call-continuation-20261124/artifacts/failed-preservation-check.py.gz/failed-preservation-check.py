import ast,difflib,hashlib,json,subprocess
from pathlib import Path
r=Path(__file__).parent
path='agent/native_main_payload.py'
a=subprocess.check_output(['git','show','9c084dc37aa8d78b67460f968eca5bae05c59a1a:'+path]).decode();b=Path(path).read_text()
old,new=ast.parse(a),ast.parse(b)
def functions(tree):
 result={}
 def visit(node,prefix=''):
  for child in ast.iter_child_nodes(node):
   if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    key=prefix+child.name
    if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):result[key]=child
    visit(child,key+'.')
   else:visit(child,prefix)
 visit(tree);return result
of,nf=functions(old),functions(new)
allowed={'NativeMainPayloadAdapter.'+s for s in ('__init__','_checkpoint','validate_scope','_around')}|{'_Admission.current','_Transport.resolve','_Transport.send','dispatch_controlled_main'}
changed=[]
for key,node in of.items():
 assert key in nf,key
 before=ast.get_source_segment(a,node);after=ast.get_source_segment(b,nf[key])
 if before!=after:changed.append(key);assert key in allowed,key
 left,right=node.args,nf[key].args
 if key=='NativeMainPayloadAdapter.__init__':
  assert right.kwonlyargs[-1].arg=='_issued_call_continuation_frame'
  assert ast.dump(right.kwonlyargs[-1].annotation)=='Name(id=\'object\', ctx=Load())'
  assert isinstance(right.kw_defaults[-1],ast.Constant) and right.kw_defaults[-1].value is None
  right.kwonlyargs.pop();right.kw_defaults.pop()
 assert ast.dump(left)==ast.dump(right),key
 assert ast.dump(node.returns) if node.returns else None == ast.dump(nf[key].returns) if nf[key].returns else None
left,right=a.splitlines(keepends=True),b.splitlines(keepends=True)
ops=difflib.SequenceMatcher(a=left,b=right,autojunk=False).get_opcodes()
insertions=[]
for tag,i,j,k,l in ops:
 if tag=='equal':continue
 assert tag=='insert',(tag,i,j)
 where=[name for name in allowed if of[name].lineno-1<=i<=of[name].end_lineno]
 assert where or i==len(left),(i,where)
 insertions.append({'old_line':i+1,'new_lines':l-k,'owners':sorted(where),'module_append':i==len(left)})
old_classes={n.name:n for n in ast.walk(old) if isinstance(n,ast.ClassDef)}
new_classes={n.name:n for n in ast.walk(new) if isinstance(n,ast.ClassDef)}
for name,node in old_classes.items():
 if name=='NativeMainPayloadAdapter':continue
 def shape(n):return [ast.dump(x,include_attributes=False) for x in n.body if isinstance(x,(ast.AnnAssign,ast.Assign))]
 assert shape(node)==shape(new_classes[name]),name
tracked=subprocess.check_output(['git','ls-files','-z']).split(b'\0');tracked=[x.decode() for x in tracked if x]
assert len(tracked)==11843
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()==[path]
out={'base':'9c084dc37aa8d78b67460f968eca5bae05c59a1a','base_tree':'a65914e16f198d6f385f95a8257e0fc09647b556',
 'tracked_paths':len(tracked),'old_functions_including_nested':len(of),'old_classes':len(old_classes),
 'changed_original_bodies':sorted(changed),'all_other_original_function_source_exact':True,
 'all_original_signatures_exact_except_last_private_constructor_keyword':True,
 'all_original_field_shapes_exact':True,'old_bytes_preserved_in_order':True,'insertions':insertions,
 'runtime_sha256':hashlib.sha256(b.encode()).hexdigest(),'base_runtime_sha256':hashlib.sha256(a.encode()).hexdigest()}
(r/'receipts/source-preservation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
