import ast,base64,csv,difflib,gzip,hashlib,io,json,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
start=time.monotonic()
r=Path(__file__).parent;out=Path('docs/evidence/accountant-native-tool-call-assistant-wire-20261124');art=out/'artifacts';art.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def archive(name,data):
 compressed=gzip.compress(data,mtime=0);(art/(name+'.gz')).write_bytes(compressed)
 return dict(path='artifacts/'+name+'.gz',bytes=len(data),sha256=h(data),compressed_sha256=h(compressed))
base_commit='565939d08635708714284531a46b5a6c389e1cca'
base=subprocess.check_output(['git','show',base_commit+':agent/native_main_payload.py']);now=Path('agent/native_main_payload.py').read_bytes();test=Path('tests/tools/test_native_tool_call_assistant_wire.py').read_bytes()
# Remove only the selected additive public members and three routing branches.
s=now.decode();prefix=s[:s.index('\n\n@dataclass(frozen=True, slots=True)\nclass NativeToolCallAssistantWireResult:')];lines=prefix.splitlines(keepends=True);ranges=[]
for node in ast.walk(ast.parse(prefix)):
 if isinstance(node,ast.FunctionDef) and node.name in ('retain_tool_call_assistant_wire','tool_call_assistant_wire_results'):
  first=min([node.lineno,*[d.lineno for d in node.decorator_list]])-1;end=node.end_lineno
  if lines[end]=='\n':end+=1
  ranges.append((first,end))
for a,b in sorted(ranges,reverse=True):del lines[a:b]
restored=''.join(lines)
for obj,method,arg in [('adapter','current','handle'),('self.adapter','resolve','self'),('self','around','callback')]:
 branch=f'        projection = _assistant_wire_window({obj})\n        if projection is not None:\n            return projection.{method}({arg})\n';assert restored.count(branch)==1;restored=restored.replace(branch,'',1)
assert restored.encode()==base
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',base_commit],text=True).splitlines()
changes=subprocess.check_output(['git','diff','--name-only',base_commit],text=True).splitlines();assert changes==['agent/native_main_payload.py']
index=subprocess.check_output(['git','diff','--cached','--name-only'],text=True);assert not index
allowed={'agent/native_main_payload.py'}
other=[path for path in tracked if path not in allowed]
expected=subprocess.check_output(['git','ls-tree','-r','--format=%(objectname)',base_commit],text=True).splitlines()
actual=subprocess.check_output(['git','hash-object','--stdin-paths'],input=''.join(json.dumps(path)+'\n' for path in other).encode()).decode().splitlines()
assert actual==[blob for path,blob in zip(tracked,expected) if path not in allowed]
write('source-preservation.json',dict(base=base_commit,base_tree='e440c6619230537b6d1357b1362b9f4b730d5165',base_paths=len(tracked),unchanged_other_paths=len(tracked)-1,old_runtime_restored_sha256=h(restored.encode()),base_runtime_sha256=h(base),runtime_sha256=h(now),test_sha256=h(test),only_old_bodies_changed=['_Admission.current','_Transport.resolve','NativeMainPayloadAdapter._around'],restored_byte_identical=True,old_signatures_records_constructors_helpers_tests_fixtures_preserved=True,mode_changes=subprocess.check_output(['git','diff','--summary',base_commit],text=True)))
api=ast.parse(s);record=next(n for n in api.body if isinstance(n,ast.ClassDef) and n.name=='NativeToolCallAssistantWireResult')
write('native-api.json',dict(record=ast.unparse(record),members=[ast.unparse(ast.FunctionDef(name=n.name,args=n.args,body=[ast.Expr(value=ast.Constant(value=Ellipsis))],decorator_list=n.decorator_list,returns=n.returns,lineno=n.lineno)) for n in ast.walk(api) if isinstance(n,ast.FunctionDef) and n.name in ('retain_tool_call_assistant_wire','tool_call_assistant_wire_results')],runtime_sha256=h(now),consumer_sha256=h(test)))
prior=(r/'receipts/first-success/native_main_payload.py').read_bytes();inverse=''.join(difflib.unified_diff(s.splitlines(keepends=True),prior.decode().splitlines(keepends=True),fromfile='a/agent/native_main_payload.py',tofile='b/agent/native_main_payload.py',n=0)).encode();delta=archive('terminal-correction-inverse.patch',inverse)
write('reused-scopes.json',dict(scope='distinct-failures::test_original_control_after_actual_output',runtime_sha256=h(prior),test_sha256=h((r/'receipts/distinct-failures/test_native_tool_call_assistant_wire.py').read_bytes()),final_runtime_sha256=h(now),inverse=delta,changes=['Add original agent to ordered shallow terminal snapshots.','Check selected expiry after all resolver callbacks.'],unchanged_control_body=ast.dump(next(n for n in ast.parse(test.decode()).body if isinstance(n,ast.FunctionDef) and n.name=='test_original_control_after_actual_output'))==ast.dump(next(n for n in ast.parse((r/'receipts/distinct-failures/test_native_tool_call_assistant_wire.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='test_original_control_after_actual_output')),fresh_current_control_execution=False,whole_file_current_success=False))
scopes=[];vectors=[];artifacts=[]
for row in json.loads((r/'receipts/budget.json').read_text())['scopes']:
 row=dict(row);name=row['name'];requested=[x for x in row.get('command',[]) if '::' in x];row['requested_ids']=requested
 xml=r/'receipts'/f'{name}.xml'
 if xml.exists():
  tree=ET.parse(xml);cases=[]
  for case in tree.findall('.//testcase'):
   cases.append(dict(classname=case.get('classname'),name=case.get('name'),seconds=float(case.get('time')),outcome='failed' if case.find('failure') is not None or case.find('error') is not None else 'passed'))
   for prop in case.findall('./properties/property'):
    if prop.get('name')=='projection_proof':vectors.append(dict(scope=name,case=case.get('name'),runtime_sha256=row['pins']['agent/native_main_payload.py'],proof=json.loads(prop.get('value'))))
  row['xml_cases']=cases
  if name=='compatibility':row['xml_limit']='The shared XML path retains only the final file. The runner log records one pass for each exact selected file.'
 for directory,suffix in [('logs','.log'),('receipts','.xml'),('receipts','.cases.jsonl'),('receipts','.json')]:
  p=r/directory/(name+suffix)
  if p.exists():artifacts.append(archive(name+suffix,p.read_bytes()))
 frozen=r/'receipts'/name
 if frozen.is_dir():
  runtime=frozen/'native_main_payload.py'
  if runtime.exists():
   patch=''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),runtime.read_text().splitlines(keepends=True),fromfile='a/agent/native_main_payload.py',tofile='b/agent/native_main_payload.py',n=0)).encode();row['source_patch']=archive(name+'-source.patch',patch)
  for p in frozen.iterdir():
   if p.name!='native_main_payload.py':artifacts.append(archive(name+'-'+p.name,p.read_bytes()))
 scopes.append(row)
write('validation-scopes.json',dict(limit_seconds=240,measured_supervisor_seconds=json.loads((r/'receipts/budget.json').read_text())['used_seconds'],scopes=scopes,whole_file_current_success=False,automatic_retries=0,CI_success_claim=False))
write('vectors.json',vectors);write('artifact-index.json',artifacts)
write('input-verification.json',json.loads((r/'receipts/input-verification.json').read_text()))
write('input-receipts.json',json.loads((r/'inputs/input-receipts.json').read_text()))
assert h(Path('/home/mersinvald/.local/share/orca/runtime/accountant/content-policy-artifacts/hpwa-p10.23/hermes_content_policy-0.4.0-py3-none-any.whl').read_bytes())=='a5952995b1090097d620660608811f90bf83433693624de60accc521a6a7453b'
smoke=json.loads((r/'logs/shared-smoke.log').read_text());assert smoke['admission'] and smoke['smoke_count']==1
for k in ('engine_sha256','version'):assert smoke[k]=={'engine_sha256':'a39f10d0b93e1eb77d36170367cd5880bfedee57497b6eda562fd5582fcc7865','version':'0.4.0'}[k]
write('dependency.json',dict(wheel_path='/home/mersinvald/.local/share/orca/runtime/accountant/content-policy-artifacts/hpwa-p10.23/hermes_content_policy-0.4.0-py3-none-any.whl',wheel_sha256='a5952995b1090097d620660608811f90bf83433693624de60accc521a6a7453b',API_sha256='4e7940a81a815f2092572aff25c608adf46a5de6bed7f432ff3098096160955d',openai='2.24.0',pydantic='2.13.4',shared_installs=1,shared_smokes=1,smoke=smoke,root_corrective_delivery=json.loads((r.parent/'orchestration-recovery-20261121/hpwa-p10.43.corrected-delivery.json').read_text()),root_correction_decision_sha256='0607a46f53389e589eb50b38090458d6a9ea28592528785ba79c24baa1657b8d',native_manifests_unchanged=True,native_installed_functional_suite=False))
# Keep exact source freezes and the new prose separate from historical source.
(r/'receipts/base-native_main_payload.py').write_bytes(base)
added=s[s.index('\n\n@dataclass(frozen=True, slots=True)\nclass NativeToolCallAssistantWireResult:'):]
new_prose=[]
for token in __import__('tokenize').generate_tokens(io.StringIO(added).readline):
 if token.type==__import__('tokenize').COMMENT:new_prose.append(token.string[1:].strip())
for n in ast.walk(ast.parse(added)):
 if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef)):
  d=ast.get_docstring(n)
  if d:new_prose.append(d)
(r/'receipts/new-prose.md').write_text('\n\n'.join(new_prose)+'\n')
print(json.dumps(dict(archive_count=len(list(art.iterdir())),vectors=len(vectors),static_seconds=time.monotonic()-start,remaining_source_paths=len(tracked)-1)))
