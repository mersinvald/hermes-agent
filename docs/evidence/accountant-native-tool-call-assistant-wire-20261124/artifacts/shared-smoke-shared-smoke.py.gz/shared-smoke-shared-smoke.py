import base64,csv,hashlib,importlib.metadata as md,inspect,io,json,sys,subprocess
from pathlib import Path
import hermes_content_policy as p
assert md.version('hermes-content-policy')=='0.4.0'
engine=Path(p.__file__)
assert hashlib.sha256(engine.read_bytes()).hexdigest()=='a39f10d0b93e1eb77d36170367cd5880bfedee57497b6eda562fd5582fcc7865'
d=md.distribution('hermes-content-policy'); record=d.read_text('RECORD'); verified={}
for name,digest,size in csv.reader(io.StringIO(record)):
 if digest:
  data=d.locate_file(name).read_bytes(); kind,value=digest.split('='); assert kind=='sha256'
  assert base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('=')==value
  assert str(len(data))==size; verified[name]=hashlib.sha256(data).hexdigest()
b=p.ExecutionBinding('owner','execution','lineage','consumer',1,1,'selection',1,())
a=type('Admission',(),{'current':lambda self,h:b})()
dest=p.Destination('invented','synthetic_native','invented_model','invented_endpoint',1)
port=type('Port',(),{'resolve':lambda self:dest,'send':lambda self,e:b'{}'})()
route=p.RouteBinding('route','selection',1,'consumer','main',dest,100,'synthetic_route','synthetic_only')
runtime=p.ContentPolicyRuntime(admission=a,profiles=(),routes=(route,),transports=(('invented',port),),clock=lambda:1,policy_revision=1)
handle=runtime.admit(object(),b'Invented shared smoke')
assert runtime._content(handle).payload==b'Invented shared smoke'
print(json.dumps(dict(version=d.version,engine_sha256=hashlib.sha256(engine.read_bytes()).hexdigest(),record_sha256=hashlib.sha256(record.encode()).hexdigest(),verified_files=verified,signatures={name:str(inspect.signature(getattr(p.ContentPolicyRuntime,name))) for name in ('admit','derive','derive_for_selection','dispatch','accept','return_from_delegate')},admission=True,smoke_count=1),indent=2))


assert md.version('openai')=='2.24.0' and md.version('pydantic')=='2.13.4'
